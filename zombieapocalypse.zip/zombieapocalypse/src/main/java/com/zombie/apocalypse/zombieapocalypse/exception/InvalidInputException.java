package com.zombie.apocalypse.zombieapocalypse.exception;

public class InvalidInputException extends Throwable {

    public InvalidInputException(String message) {
        super(message);
    }
}
