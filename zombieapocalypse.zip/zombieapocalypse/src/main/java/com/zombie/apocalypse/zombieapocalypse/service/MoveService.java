package com.zombie.apocalypse.zombieapocalypse.service;

import com.zombie.apocalypse.zombieapocalypse.enums.Direction;
import com.zombie.apocalypse.zombieapocalypse.model.Creature;
import com.zombie.apocalypse.zombieapocalypse.model.World;
import org.springframework.stereotype.Service;

@Service
public class MoveService {

    public void move(Creature zombie, Direction direction, World world) {
    }
}
