package com.zombie.apocalypse.zombieapocalypse;

import com.zombie.apocalypse.zombieapocalypse.controller.ZombieMovementController;
import com.zombie.apocalypse.zombieapocalypse.exception.InvalidInputException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZombieApocalypseApplication {

	public static void main(String[] args) throws InvalidInputException {
		SpringApplication.run(ZombieApocalypseApplication.class, args);
		new ZombieMovementController().move();
	}

}
