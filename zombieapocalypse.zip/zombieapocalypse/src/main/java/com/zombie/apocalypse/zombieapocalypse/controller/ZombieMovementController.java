package com.zombie.apocalypse.zombieapocalypse.controller;

import com.zombie.apocalypse.zombieapocalypse.exception.InvalidInputException;
import com.zombie.apocalypse.zombieapocalypse.model.Creature;
import com.zombie.apocalypse.zombieapocalypse.enums.Direction;
import com.zombie.apocalypse.zombieapocalypse.model.Position;
import com.zombie.apocalypse.zombieapocalypse.model.World;
import com.zombie.apocalypse.zombieapocalypse.service.MoveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.*;

@Controller
public class ZombieMovementController {

    private World world;

    private List<Direction> directions;

    private Queue<Creature> zombies;

    private List<Position> zombiePositions;

    private int zombieScore;

    public ZombieMovementController(){
        world = new World(
            4,
                new Creature(new Position(2 , 1), true),
                List.of(
                        new Creature(new Position(0 , 1), false),
                        new Creature(new Position(1 , 2), false),
                        new Creature(new Position(3 , 1), false)
                        )
        );

        directions = new ArrayList<>();
        directions.add(Direction.DOWN);
        directions.add(Direction.LEFT);
        directions.add(Direction.UP);
        directions.add(Direction.UP);
        directions.add(Direction.RIGHT);
        directions.add(Direction.RIGHT);

        zombies = new LinkedList<>();
        zombiePositions = new LinkedList<>();
    }

    public void move() throws InvalidInputException {
        zombies.add(world.getZombie());
        while (!zombies.isEmpty()) {
            world.setZombie(zombies.poll());
            for (Direction direction : directions) {
                Optional<Creature> affectedCreature = world.moveZombie(direction);
                affectedCreature.ifPresent(
                        creature -> {
                            zombies.add(creature);
                            zombieScore++;
                        }
                );
            }
            zombiePositions.add(world.getZombie().getCurrentPosition());
        }

        System.out.println("Positions: ");
        for (Position pos:zombiePositions) {
            System.out.println("("+pos.getXCoordinate()+","+pos.getYCoordinate()+") \n");
        }
        System.out.println("zombieScore: " + zombieScore);
    }
}