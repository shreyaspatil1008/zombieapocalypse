package com.zombie.apocalypse.zombieapocalypse.model;

import com.zombie.apocalypse.zombieapocalypse.enums.Direction;
import com.zombie.apocalypse.zombieapocalypse.exception.InvalidInputException;
import lombok.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class World {

    private Integer dimensions;

    private Map<Position,Creature> positions;

    private Creature zombie;

    private List<Creature> creatures;

    public World(Integer dimensions, Creature zombie, List<Creature> creatures) {
        this.dimensions = dimensions;
        this.positions = new LinkedHashMap<>();
        this.zombie = zombie;
        this.creatures = creatures;
        initPositions();
        keepCreaturesOnTheirPositions();
    }

    private void keepCreaturesOnTheirPositions() {
        for(Creature creature: creatures) {
            positions.put(creature.getCurrentPosition(), creature);
        }
    }

    private void initPositions() {
        for (int xDimension = 0; xDimension < dimensions ; xDimension ++) {
            for (int yDimension = 0; yDimension < dimensions ; yDimension ++) {
                Position position = new Position(xDimension, yDimension);
                positions.put(position, null);
            }
        }
    }


    public Optional<Creature> moveZombie(Direction direction) throws InvalidInputException {
        Position newZombiePosition = zombie.getCurrentPosition().move(direction, dimensions);
        Creature creature = positions.get(newZombiePosition);
        zombie.setCurrentPosition(newZombiePosition);
        if(null != creature && !creature.isZombie()) {
            creature.setZombie(true);
            positions.put(newZombiePosition, creature);
            System.out.println("creature: "+ creature);
            return Optional.of(creature);
        }
        return Optional.empty();
    }
}
