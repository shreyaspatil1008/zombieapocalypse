package com.zombie.apocalypse.zombieapocalypse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZombieApocalypseApplicationTests {

	@Test
	void contextLoads() {
	}

}
